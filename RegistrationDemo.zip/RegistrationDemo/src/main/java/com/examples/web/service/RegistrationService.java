package com.examples.web.service;

import com.examples.web.domain.Registration;

public interface RegistrationService {
	
	public void insertRegistration(Registration registration);

}
