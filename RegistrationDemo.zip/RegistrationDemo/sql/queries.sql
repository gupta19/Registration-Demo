create table Registration(FIRST_NAME varchar2(20),
						LAST_NAME VARCHAR2(20),
						USER_NAME VARCHAR2(20) PRIMARY KEY,
						PASSWORD  VARCHAR2(10),
						EMAIL  VARCHAR2(50)		
);